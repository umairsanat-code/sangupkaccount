@extends('layouts.master')
@section('content')

    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Create Ticket</h1>
                    </div>
                </div>
            </div>
        </section>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header" style="background-color: white;">
                            <h3 class="card-title">Add New Ticket</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('daily_report.update', $ticket->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="date">Date</label>
                                            <input type="date" class="form-control" name="date" id="date" value="{{ old('date', $ticket->date) }}">
                                            @error('date')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="time">Time</label>
                                            <input type="time" class="form-control" name="time_limit" id="time_limit" value="{{ old('time_limit', $ticket->time_limit) }}">
                                            @error('time_limit')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="ticket_number">Ticket Number</label>
                                            <input type="text" name="ticket_number" class="form-control @error('ticket_number') is-invalid @enderror" value="{{ old('ticket_number', $ticket->ticket_number) }}" required>
                                            @error('ticket_number')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="pnr">PNR</label>
                                            <input type="text" name="pnr" class="form-control @error('pnr') is-invalid @enderror" value="{{ old('pnr', $ticket->pnr) }}" required>
                                            @error('pnr')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="issued_price">Issue Amount</label>
                                            <input type="text" name="issued_price" class="form-control @error('issued_price') is-invalid @enderror" value="{{ old('issued_price', $ticket->issued_price) }}" required>
                                            @error('issued_price')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="pax_name">Pax Name</label>
                                            <input type="text" name="pax_name" class="form-control @error('pax_name') is-invalid @enderror" value="{{ old('pax_name', $ticket->pax_name) }}" required>
                                            @error('pax_name')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="system">System</label>
                                            <input type="text" name="system" class="form-control @error('system') is-invalid @enderror" value="{{ old('system', $ticket->system) }}" required>
                                            @error('system')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="remarks">Remarks</label>
                                            <textarea name="remarks" class="form-control">{{ old('remarks', $ticket->remarks) }}</textarea>
                                            @error('remarks')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="payment_method">Payment Method</label>
                                            <select name="payment_method" class="form-control @error('payment_method') is-invalid @enderror" required>
                                                <option value="">Select Status</option>
                                                <option value="paid" {{ old('payment_method', $ticket->payment_method) == 'paid' ? 'selected' : '' }}>Paid</option>
                                                <option value="unPaid" {{ old('payment_method', $ticket->payment_method) == 'unPaid' ? 'selected' : '' }}>Unpaid</option>
                                            </select>
                                            @error('payment_method')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="sale_price">Sale Price</label>
                                            <input type="text" name="sale_price" class="form-control @error('sale_price') is-invalid @enderror" value="{{ old('sale_price', $ticket->sale_price) }}" required>
                                            @error('sale_price')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="payment">Payment</label>
                                            <input type="text" name="payment" class="form-control @error('payment') is-invalid @enderror" value="{{ old('payment', $ticket->payment) }}" required>
                                            @error('payment')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Update Ticket</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
