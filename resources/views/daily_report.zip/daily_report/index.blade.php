@extends('layouts.master')

@section('content')
    <div class="content-wrapper">
    <div class="container">
        <h2>Daily Sale Tickets</h2>
        <a href="{{ route('daily_report.create') }}" class="btn btn-primary mb-3">Add New Ticket</a>

        <table class="table table-bordered" id="dailyTable">
            <thead>
            <tr>
                <th>#</th>
                <th>Dated</th>
                <th>Time</th>
                <th>PNR</th>
                <th>System</th>
                <th>Issued Price</th>
                <th>Sale Price</th>
                <th>Pending Price</th>
                <th>Note</th>
                <th>Action</th>
            </tr>
            </thead>
        </table>
    </div>
    </div>

@endsection
@section('script')
    <script>
        $(document).ready(function() {
            $('#dailyTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "{{ route('daily_report.index') }}",
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                    { data: 'date', name: 'date' },
                    { data: 'time_limit', name: 'time_limit' },
                    { data: 'pnr', name: 'pnr' },
                    { data: 'system', name: 'system' },
                    { data: 'issued_price', name: 'issued_price' },
                    { data: 'sale_price', name: 'sale_price' },
                    { data: 'pendings', name: 'pendings' },
                    { data: 'remarks', name: 'remarks' },
                    { data: 'action', name: 'action', orderable: false, searchable: false }
                ]
            });
        });
    </script>
@endsection
