@extends('layouts.master')
@section('content')

    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Create Ticket</h1>
                    </div>
                </div>
            </div>
        </section>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header" style="background-color: white;">
                            <h3 class="card-title">Add New Ticket</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('daily_report.store') }}" method="POST">
                                @csrf

                                <div class="row">

                                    <!-- Customer and Flight Date fields in one row -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="customer_id">Date</label>
                                            <input type="date"  class="form-control" name="date" id="date">
                                            @error('date')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="time_limit">Time</label>
                                            <input type="time" class="form-control" name="time_limit" id="time_limit">

                                            @error('time_limit')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Ticket Number and Airline fields in one row -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="ticket_number">Ticket Number</label>
                                            <input type="text" name="ticket_number" class="form-control @error('ticket_number') is-invalid @enderror" value="{{ old('ticket_number') }}" required>
                                            @error('ticket_number')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="flight_date">PNR</label>
                                            <input type="text" name="pnr" class="form-control @error('pnr') is-invalid @enderror" value="{{ old('pnr') }}" required>
                                            @error('pnr')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Booking Date and Departure City fields in one row -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="booking_date">Issue Amount</label>
                                            <input type="text" name="issued_price" class="form-control @error('issued_price') is-invalid @enderror" value="{{ old('issued_price') }}" required>
                                            @error('issued_price')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="departure_city">Pax Name</label>
                                            <input type="text" name="pax_name" class="form-control @error('pax_name') is-invalid @enderror" value="{{ old('pax_name') }}" required>
                                            @error('pax_name')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Destination City and Class fields in one row -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="system">System</label>
                                            <input type="text" name="system" class="form-control @error('system') is-invalid @enderror" value="{{ old('system') }}" required>
                                            @error('system')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="system"></label>
                                            <textarea name="remarks" class="form-control"></textarea>
                                            @error('remarks')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <!-- Status and Purchase Price fields in one row -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="status">payment_method</label>
                                            <select name="payment_method" class="form-control @error('payment_method') is-invalid @enderror" required>
                                                <option value="">Select Status</option>
                                                <option value="paid" {{ old('payment_method') == 'paid' ? 'selected' : '' }}>Paid</option>
                                                <option value="unPaid" {{ old('payment_method') == 'unPaid' ? 'selected' : '' }}>unPaid</option>
                                            </select>
                                            @error('status')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="purchase_price">Sale Price</label>
                                            <input type="text" name="sale_price" class="form-control @error('sale_price') is-invalid @enderror" value="{{ old('sale_price') }}" required>
                                            @error('sale_price')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <!-- Status and Purchase Price fields in one row -->
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label for="sale_price">Sale Price</label>
                                            <input type="number" step="0.01" name="sale_price" class="form-control @error('sale_price') is-invalid @enderror" value="{{ old('sale_price') }}" required>
                                            @error('sale_price')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>


                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="sale_date">payment</label>
                                            <input type="text" name="payment" class="form-control @error('payment') is-invalid @enderror" value="{{ old('payment') }}" required>
                                            @error('payment')
                                            <span class="invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>


                                    </div>
                                </div>


                                <button type="submit" class="btn btn-primary">Create Ticket</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
