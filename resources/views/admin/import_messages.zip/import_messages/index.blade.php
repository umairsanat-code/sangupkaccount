@extends('layouts.master')
<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.0/dist/sweetalert2.min.css">

@section('content')
    <div class="content-wrapper">
        <div class="container">
            <h2>Messages List</h2>
            <div class="d-flex justify-content-end mb-3">

                <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#createExpenseModal">New Message</button>

            </div>
            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif


            <div class="card">
                <div class="card-body">
                    {{--            <table class="table table-bordered" id="agent-table">--}}
                    <table id="messageTable" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Sender Name</th>
                            <th>Receive Name</th>
                            <!--<th>Ticket Number</th>-->
                            <th>Message</th>
                            <th>Is_Read</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="createExpenseModal" tabindex="-1" aria-labelledby="createExpenseModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="messageForm" method="POST">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title" id="createExpenseModalLabel">Add New Message</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                       
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" name="message" rows="4" placeholder="Enter your message" required></textarea>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>






@endsection
@section('script')
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
{{--    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>--}}
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.0/dist/sweetalert2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.ticket-select').select2({
                placeholder: "Search Ticket",
                allowClear: true,
                width: '100%',
                color:black,
            });
        });
        document.addEventListener("DOMContentLoaded", function () {
            let ticketId = "1";
            $(document).ready(function () {
                var table = $('#messageTable').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: "{{ route('import_messsage') }}",
                        // data: function (d) {
                        //     d.startDate = $('#startDate').val();
                        //     d.endDate = $('#endDate').val();
                        // }
                    },
                    columns: [
                        { data: 'date', name: 'date' },
                        { data: 'sender_name', name: 'sender_name' },
                        { data: 'receive_name', name: 'receive_name' },
                        { data: 'message', name: 'message' },
                        // { data: 'ticket_number', name: 'ticket_number' },
                        { data: 'is_read', name: 'is_read' },

                    ],
                    drawCallback: function (settings) {
                        // var totalAmount = settings.json.totalAmount || '0.00';
                        // var totalCount = settings.json.totalCount || '0';

                        // $('#totalAmount').text(totalAmount);
                        // $('#totalCount').text(totalCount);
                    }
                });

                $('#filterBtn').on('click', function () {
                    table.ajax.reload();
                });
            });

        });
    </script>
    <script>
        $(document).ready(function() {
            $("#messageForm").submit(function(e) {
                e.preventDefault(); // Prevent default form submission

                $.ajax({
                    url: "{{ route('messages') }}", // Ensure this route exists in web.php
                    type: "POST",
                    data: $(this).serialize(),
                    headers: {
                        'X-CSRF-TOKEN': "{{ csrf_token() }}" // CSRF token for security
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: "success",
                            title: "Message Sent",
                            text: "Your message has been successfully sent!",
                            timer: 2000,
                            showConfirmButton: false
                        });

                        $('#createExpenseModal').modal('hide'); // Close modal after submission
                        $("#messageForm")[0].reset(); // Reset the form
                    },
                    error: function(xhr) {
                        let errors = xhr.responseJSON.errors;
                        let errorMessage = "Something went wrong!";

                        if (errors) {
                            errorMessage = Object.values(errors).flat().join("\n");
                        }

                        Swal.fire({
                            icon: "error",
                            title: "Error",
                            text: errorMessage
                        });
                    }
                });
            });
        });
    </script>
@endsection
